import math
degree = math.pi/180
print(30*degree)
print(-55.12*degree)
print(90.53*degree)